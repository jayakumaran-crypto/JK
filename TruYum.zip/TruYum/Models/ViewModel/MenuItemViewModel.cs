﻿namespace TruYum.Models.ViewModel
{
    public class MenuItemViewModel
    {
        public Menuitem MenuItem { get; set; }
        public IEnumerable<Category> Categories { get; set; }
    }
}