﻿using System.ComponentModel.DataAnnotations;

namespace TruYum.Models
{
    public class Cart
    {
        [Key]
        public int Id { get; set; }

        public ICollection<Menuitem> MenuItems { get; set; }

        public int UserId { get; set; }
    }
}
