﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace TruYum.Models
{
    public class TruYumContext : DbContext
    {
        public TruYumContext()
            : base("Data Source=LTIN315975\\SQLEXPRESS;Initial Catalog=TruYum;Integrated Security=True")
        {
        }

        public DbSet<Menuitem> MenuItems { get; set; }

        public DbSet<Category> Categories { get; set; }

        public DbSet<Cart> Carts { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder) 
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>(); 
        }
    }
}
