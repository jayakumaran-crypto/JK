﻿namespace TruYum.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addingdatasets : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Cart",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Menuitem",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 300),
                        Price = c.Double(nullable: false),
                        FreeDelivery = c.Boolean(nullable: false),
                        DateOfLauch = c.DateTime(nullable: false),
                        CategoryId = c.Int(nullable: false),
                        Active = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Category", t => t.CategoryId, cascadeDelete: true)
                .Index(t => t.CategoryId);
            
            CreateTable(
                "dbo.Category",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 300),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.MenuitemCart",
                c => new
                    {
                        Menuitem_Id = c.Int(nullable: false),
                        Cart_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Menuitem_Id, t.Cart_Id })
                .ForeignKey("dbo.Menuitem", t => t.Menuitem_Id, cascadeDelete: true)
                .ForeignKey("dbo.Cart", t => t.Cart_Id, cascadeDelete: true)
                .Index(t => t.Menuitem_Id)
                .Index(t => t.Cart_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Menuitem", "CategoryId", "dbo.Category");
            DropForeignKey("dbo.MenuitemCart", "Cart_Id", "dbo.Cart");
            DropForeignKey("dbo.MenuitemCart", "Menuitem_Id", "dbo.Menuitem");
            DropIndex("dbo.MenuitemCart", new[] { "Cart_Id" });
            DropIndex("dbo.MenuitemCart", new[] { "Menuitem_Id" });
            DropIndex("dbo.Menuitem", new[] { "CategoryId" });
            DropTable("dbo.MenuitemCart");
            DropTable("dbo.Category");
            DropTable("dbo.Menuitem");
            DropTable("dbo.Cart");
        }
    }
}
